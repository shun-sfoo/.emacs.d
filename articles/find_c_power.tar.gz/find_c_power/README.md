# (19 封私信 / 2 条消息) 找回 C 语言的力量

> 共 12 篇，导出于 2026-03-22

1. [C 对象 - YAML](./articles/C%20%E5%AF%B9%E8%B1%A1%20-%20YAML.md) - （文章）
2. [C 语言初学者，请和我一起写字符串模块吧！](./articles/C%20%E8%AF%AD%E8%A8%80%E5%88%9D%E5%AD%A6%E8%80%85%EF%BC%8C%E8%AF%B7%E5%92%8C%E6%88%91%E4%B8%80%E8%B5%B7%E5%86%99%E5%AD%97%E7%AC%A6%E4%B8%B2%E6%A8%A1%E5%9D%97%E5%90%A7%EF%BC%81.md) - （文章）
3. [C 语言动态数组的一种实现](./articles/C%20%E8%AF%AD%E8%A8%80%E5%8A%A8%E6%80%81%E6%95%B0%E7%BB%84%E7%9A%84%E4%B8%80%E7%A7%8D%E5%AE%9E%E7%8E%B0.md) - （文章）
4. [V 是生命，也是水池……](./articles/V%20%E6%98%AF%E7%94%9F%E5%91%BD%EF%BC%8C%E4%B9%9F%E6%98%AF%E6%B0%B4%E6%B1%A0%E2%80%A6%E2%80%A6.md) - （文章）
5. [YAML - C 对象](./articles/YAML%20-%20C%20%E5%AF%B9%E8%B1%A1.md) - （文章）
6. [YAML 小传](./articles/YAML%20%E5%B0%8F%E4%BC%A0.md) - （文章）
7. [一种关于 C 程序错误的哲学](./articles/%E4%B8%80%E7%A7%8D%E5%85%B3%E4%BA%8E%20C%20%E7%A8%8B%E5%BA%8F%E9%94%99%E8%AF%AF%E7%9A%84%E5%93%B2%E5%AD%A6.md) - （文章）
8. [作为 C 程序配置语言的 Lua](./articles/%E4%BD%9C%E4%B8%BA%20C%20%E7%A8%8B%E5%BA%8F%E9%85%8D%E7%BD%AE%E8%AF%AD%E8%A8%80%E7%9A%84%20Lua.md) - （文章）
9. [盒子与函数的一阶多态](./articles/%E7%9B%92%E5%AD%90%E4%B8%8E%E5%87%BD%E6%95%B0%E7%9A%84%E4%B8%80%E9%98%B6%E5%A4%9A%E6%80%81.md) - （文章）
10. [类型、回调函数及二阶多态](./articles/%E7%B1%BB%E5%9E%8B%E3%80%81%E5%9B%9E%E8%B0%83%E5%87%BD%E6%95%B0%E5%8F%8A%E4%BA%8C%E9%98%B6%E5%A4%9A%E6%80%81.md) - （文章）
11. [让宏看上去像函数的办法](./articles/%E8%AE%A9%E5%AE%8F%E7%9C%8B%E4%B8%8A%E5%8E%BB%E5%83%8F%E5%87%BD%E6%95%B0%E7%9A%84%E5%8A%9E%E6%B3%95.md) - （文章）
12. [请不要和我说宏很危险](./articles/%E8%AF%B7%E4%B8%8D%E8%A6%81%E5%92%8C%E6%88%91%E8%AF%B4%E5%AE%8F%E5%BE%88%E5%8D%B1%E9%99%A9.md) - （文章）
