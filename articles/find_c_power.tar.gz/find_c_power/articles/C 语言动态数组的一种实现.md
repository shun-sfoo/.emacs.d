---
id: "2017968626427265163"
title: "C 语言动态数组的一种实现"
author: "李缓慢"
type: zhihu-article
source: "https://zhuanlan.zhihu.com/p/2017968626427265163"
created: "2026-03-19 15:59"
downloaded: "2026-03-22"
---
如果你曾经「[和我一起写过字符串模块](https://zhuanlan.zhihu.com/p/2017058188965459813)」，并且能接受「[一种关于 C 程序错误的哲学](https://zhuanlan.zhihu.com/p/2017649359882318343)」，那么实现动态数组模块已经毫无难度可言了。字符串本质上是一种特殊的数组——每个元素的长度是 1 个字节。动态数组不拘囿元素长度，只是要求所有元素的长度相等，故而动态数组的类型可设计为

```c
typedef struct {
        size_t n;   /* 数组元素数量 */
        size_t u;   /* 数组元素的长度 */
        size_t m;   /* body 所指区域的长度 */
        void *body; /* 指向存放数组元素的空间 */
} WkArray;
```

在构造空的动态数组时，需要知道数组元素的长度，故而动态数组的构造函数需可定义为

```c
WkArray *WK_ARRAY(size_t u) {
        WkArray *array = malloc(sizeof(WkArray));
        if (!array) wk_err("failed to create WkArray object");
        *array = (WkArray){0, u, 0, NULL};
        return array;
        wk_fallback_with(NULL);
}
```

函数名之所以大写，是基于「[盒子与一阶多态函数](https://zhuanlan.zhihu.com/p/2017756891640504900)」提出的命名原则，凡不便使用的函数，其名字需大写，然后再为其定义一个便于使用的宏：

```c
#define wk_array(type) WK_ARRAY(sizeof(type))
```

> 这是 WK 项目的编码风格之一，以后我就不再啰唆了。

`wk_array` 宏的用法如下：

```c
/* 构造用于存储 int 类型数据的动态数组 */
WkArray *a = wk_array(int);
```

与动态字符串不同，动态数组不支持在首部或数组内任意一处插入数据，它只支持尾向生长，实现这一生长方式的函数是 `WK_ARRAY_ADD`：

```c
void WK_ARRAY_ADD(WkArray *array, void *unit, size_t u) {
        if (!unit) wk_err("invalid unit");
        if (array->u != u) wk_err("unit size not matched");
        if (!array->body) {
                array->body = malloc(u);
                if (!array->body) wk_err("memory not enough");
                array->m = u;
        } else {
                size_t t = (array->n + 1) * u;
                if (t > array->m) {
                        size_t m = t << 1; /* 容量倍增 */
                        void *new_body = realloc(array->body, m);
                        if (!new_body) wk_err("memory not enough");
                        array->body = new_body;
                        array->m = m;
                }
        }
        memcpy((char *)(array->body) + array->n * u, unit, u);
        array->n++;
        wk_fallback;
}
```

`WK_ARRAY_ADD` 函数的简便宏定义如下：

```c
#define wk_array_add(array, U, T) do { \
        T _tmp_unit_ = U; \
        WK_ARRAY_ADD(array, &_tmp_unit_, sizeof(T)); \
} while (0)
```

显然，`wk_array_add` 是支持字面量的，故而可以像下面这样使用动态数组：

```c
WkArray *a = wk_array(int);
wk_array_add(a, 1, int);
wk_array_add(a, 2, int);
wk_array_add(a, 3, int);
for (size_t i = 0; i < a->n; i++) {
        printf("%d\n", *(int *)((char *)a->body + i * array->u));
}
/* 以下语句会导致 WK_ARRAY 函数报错： */
/* unit size not matched          */
wk_array_add(a, 3.14, double);
```

> 之所以将 `a->body` 强制转换为 `char *`，是因为 `void` 指针不支持数学运算。

上述代码对数组元素取值很容易让人写错，故而也需要定义为函数与宏：

```c
#define wk_array_get(array, i, type) \
        *(type *)WK_ARRAY_GET(array, i, sizeof(type))

const void *WK_ARRAY_GET(WkArray *array, size_t i, size_t u) {
        if (!array) wk_err("invalid WkArray Object");
        if (array->u < u) wk_err("unit size not matched");
        if (i >= array->n) wk_err("out-of-bounds access");
        return (char *)(array->body) + i * u;
        wk_fallback_with(NULL);
}
```

`wk_array_get` 宏的用法如下：

```c
WkArray *a = wk_array(int);
wk_array_add(a, 1, int);
wk_array_add(a, 2, int);
wk_array_add(a, 3, int);
for (size_t i = 0; i < a->n; i++) {
        printf("%d\n", wk_array_get(a, i, int));
}
```

`wk_array_add` 的主要作用是在向数组添加新元素的过程中促使数组扩容。为了方便修改数组中某个单元里的元素，还需要提供 `WK_ARRAY_PUT`/`wk_array_put` ：

```c
#define wk_array_put(array, index, U, T) do {     \
        T _tmp_unit_ = U; \
        WK_ARRAY_PUT(array, index, &_tmp_unit_, sizeof(T)); \
} while (0)

void WK_ARRAY_PUT(WkArray *array, size_t i, void *unit, size_t u) {
        if (array->u < u) wk_err("unit size not matched");
        if (i >= array->n) wk_err("out-of-bounds access");
        memcpy((char *)(array->body) + i * u, unit, u);
        wk_fallback;
}
```

显然，`wk_array_put` 也支持字面量，其用法如下：

```c
/* 构造一个含有 100 个元素的数组 */
WkArray *a = wk_array(int);
for (size_t i = 0; i < 100; i++) {
        wk_array_add(a, i, int);
}
/* 令 a 的第 42 个单元的值为 -1 */
wk_array_put(a, 41, -1, int);
```

上述函数/宏已经足以使得 `WkArray` 类型行走江湖了，只是还缺乏删除数组中某个单元的函数/宏。我犹豫了很久，最终还是添加了这一功能，以满足那些不想使用链表的人……当然，我们现在还没有链表可用。`wk_array_del` 用于删除数组中指定下标的单元，定义如下：

```c
void wk_array_del(WkArray *array, size_t i) {
        if (!array) wk_err("invalid WkArray Object");
        if (i >= array->n) wk_err("out-of-bounds access");
        /* 将 [i + 1, array->n) 向左移一个单元 */
        char *a = array->body; /* 将 void * 转化为 char *，使之支持指针运算 */
        size_t u = array->u;
        size_t stop = array->n - 1;
        for (size_t j = i; j < stop; j++) {
                memcpy(a + j * u, a + (j + 1) * u, u);
        }
        array->n -= 1; /* 更新元素数量 */
        /* 缩容 */
        size_t new_m = (array->n << 1) * u;
        if (new_m > 0 && array->m > new_m) {
                void *new_body = realloc(array->body, new_m);
                if (!new_body) wk_err("memory not enough");
                array->body = new_body;
                array->m = new_m;
        }
        wk_fallback;
}
```

> 现在，我告诉你，C 标准库有函数 `memmove`，它能够将 n 个字节的内存区域中的内容整体搬运到指定区域。你知道如何基于该函数修改上述代码吗？

`wk_array_del` 可在删除数组单元的过程中，适度缩小数组空间长度——为了让 `realloc` 的行为足够确定，不可能缩小为 0 长度空间——，其用法如下：

```c
WkArray *x = wk_array(int);
int a[] = {0, 1, 2, 3, 4};
size_t n = sizeof(a) / sizeof(int);
for (size_t i = 0; i < n; i++) {
        wk_array_add(x, a[i], int);
}
/* 删除下标为 3 的单元 */
wk_array_del(x, 3);
/* 释放 x */
wk_array_free(x);
```

注意，我没有提供 `WkArray` 对象的释放函数，因为它太简单了，你就当 `wk_array_free` 已经存在了吧，毕竟我只是在尽力从图像上描绘动态数组应该有的样子，请不要指责这幅图像不像照片。另外，在使用 `wk_array_del` 时需要注意，过河时切勿拆桥……

在设计和实现动态数组的过程中，我用了一些宏，错误处理机制也是基于宏实现的。一定会有人说宏的各种不好。他们说的是对的。不过，在你「[和我一起写过字符串模块](https://zhuanlan.zhihu.com/p/2017058188965459813)」时，一开始我就说，编程很像一种开放式的游戏。宏是这个游戏里的一种几乎完全不讲游戏规则的怪物，需要想办法去征服它，而不是从一开始就逃避。如果你对宏的好处和风险几乎一无所知，又如何欣赏 C++ 的泛型呢？