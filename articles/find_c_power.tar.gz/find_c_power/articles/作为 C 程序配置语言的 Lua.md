---
id: "1917931954260653930"
title: "作为 C 程序配置语言的 Lua"
author: "李缓慢"
type: zhihu-article
source: "https://zhuanlan.zhihu.com/p/1917931954260653930"
created: "2025-06-16 13:14"
downloaded: "2026-03-22"
---
**上一篇**：

[https://zhuanlan.zhihu.com/p/1917295757779769223](https://zhuanlan.zhihu.com/p/1917295757779769223)

## 前言

对于 C 程序而言，若使用 YAML 作为配置或数据交换语言，需要接受 libyaml 库用法上的一些折磨。这些折磨并非没有益处，除了我的 C 程序能支持 YAML 之外，也让我觉得，用 Lua 作为 C 程序的配置和数据交换语言是更好的选择。

用 Lua 语言为 C 程序写配置文件，或者作为 C 程序间的数据传递协议，并不需要掌握如何用 Lua 语言编写程序，因为这两项需求，所用的主要是 Lua 语言的数据表达形式，亦即将 Lua 语言视为 YAML 这样的数据描述语言。

由于 Lua 的数据类型是动态的，除了基本类型，还有功能强大的表类型，足以描述复杂的数据对象。只要将 Lua 解释器嵌入 C 程序，便可很容易从作为配置或数据传递协议的 Lua 文件里获取所需类型的数据，而不是像 libyaml 那样，只能从 YAML 文件里获得文本形式的数据。

以上只是我的想象。这份文档是一个初步尝试，让这想象变为现实。不过，它一定会变为现实的，因为 Lua 语言主要就是为这一想象而设计的语言。

## Lua 脚本

以下 Lua 代码定义了一个变量：

```lua
地名 = "小沛"
```

显然，即使你不懂 Lua 语言，也能领会到它所表达的数据的形式和含义。上述 Lua 变量，用 YAML 语言可表达为一个键值对构成的映射：

```yaml
地名: 小沛
```

Lua 语言作为数据语言，比 YAML 略微逊色之处是，需要一些引号表明某些文本是字符串，但这也是 Lua 胜过 YAML 之处，即 Lua 语言作为数据语言，它所描述的数据是有类型的，而 YAML 里的数据，一切皆文本，故而通常情况下可忽略引号。

假设上述的 Lua 变量的定义存放在文件 foo.lua 里。我们的任务是，在一个 C 程序里，读入解析 foo.lua，获得其中数据。含有 Lua 代码的文件，我们称为 Lua 脚本。

## Lua 解释器

在 C 程序中，Lua 解释器以 `lua_State` 类型的对象表示，通过函数 `luaL_newstate` 便可创造该类型的对象，从而开启一个 Lua 解释器。例如

```c
lua_State *L = luaL_newstate(); /* 创建 Lua 解释器 */
```

上述代码开启的 Lua 解释器，只能用于解释简单的 Lua 代码，如同没有标准库的 C 语言，想要在屏幕上输出 `Hello world!` 也是件难事。我们可以使用 `luaL_openlibs` 函数为这个解释器开启标准库，便可得到功能齐备的 Lua 解释器了。

```c
luaL_openlibs(L); /* 开启标准库 */
```

Lua 解释器完成任务后，可通过 `lua_close` 函数关闭以回收其所占资源。例如

```c
lua_close(L); /* 关闭 Lua 解释器 */
```

以下代码实现了一个完整的程序，用于演示在 C 程序中如何开启和关闭 Lua 解释器。

```c
/* foo.c */
#include <stdio.h>
#include <lua.h>     /* 提供所有前缀为 lua_ 的函数 */
#include <lauxlib.h> /* 提供所有前缀为 luaL_ 的函数 */
#include <lualib.h>  /* 提供 luaL_openlibs 函数 */

int main(void) {
    lua_State *L = luaL_newstate(); 
    luaL_openlibs(L);

    lua_close(L);
    return 0;
}
```

假设将上述代码保存在 foo.c 文件——为了便于叙述，下文会在代码头部直接给出文件名——，使用以下命令便可编译 foo.c：

```console
$ gcc foo.c -o foo -I/usr/include/lua5.4 -llua5.4
```

上述 gcc 命令选项指定了 Lua 5.4 的头文件目录（/usr/include/lua5.4）以及所连接的库文件名（liblua5.4.so）。在 Ubuntu 或其衍生版本的 Linux 系统里，可能会有多个 Lua 版本，故而在编译嵌入 Lua 解释器的 C 代码时，需要指定相应版本的 Lua 库的头文件目录以及库文件版本。

若不想在 gcc 命令里显式设定 Lua 库的头文件目录，可在代码里给出头文件目录，例如

```c
#include <lua5.4/lua.h>
#include <lua5.4/lauxlib.h>
#include <lua5.4/lualib.h>
```

上述由 foo.c 编译成的程序 foo，运行它，没有任何输出，因为它内嵌的 Lua 解释器还缺乏具体要执行的任务。

## 载入 Lua 脚本

在 C 程序中创建了 Lua 解释器之后，可使用 `luaL_loadfile` 函数，载入指定的 Lua 脚本，并将其交由解释器处理。例如，载入上文我们作为示例的 foo.lua 文件，只需

```c
if (luaL_loadfile(L, "foo.lua")) {
    fprintf(stderr, "failed to load lua script.\n");
    exit(EXIT_FAILURE);
}
```

`luaL_loadfile` 函数若执行成功，会返回 0。若该函数返回值非 0，则意味着文件载入或解释过程出错。以 0 作为函数成功标志，是 C 的传统。

不过，对于上文给出的 foo.lua，`luaL_loadfile` 会失败，原因是 Lua 语言直至现在（版本 5.4.6）依然不支持以中文作为变量名，亦即配置文件里的键值对，键名不可以是中文。要让 Lua 语言支持中文变量名，需要对其源码进行修改，编译为非标准的 Lua 解释器，但这样做就相当于制造了一门 Lua 方言。

我想用标准 Lua 语言，不得不将 foo.lua 里的中文变量名改成英文名，不过可以加上中文注释，例如

```lua
-- 地名: 小沛
place = "小沛"
```

或

```lua
place = "小沛" -- 地名: 小沛
```

上述代码中的 `--` 是 Lua 语言的注释符，其后且与其同一行的文本会被 Lua 解释器视为注释而忽略。在配置文件的键名方面，Lua 语言落后了一个时代，希望以后的版本能支持中文变量名。

载入的 Lua 文件，会被 Lua 解释器编译为字节码，即 Lua 解释器可执行的指令。Lua 解释器是无法直接执行将一个值赋予一个变量这样的命令，原因是 Lua 命令本质上是函数。对于载入的文件，Lua 会在其内容之外封装一个匿名函数，例如

```lua
function () {
    place = "小沛"
}
```

Lua 将上述代码编译为可执行的指令，并将其放在 `L` 内部的一个栈结构的顶端，我们将这个栈结构称为 Lua 栈。

既然你在阅读此文，说明你了解 C 语言甚至对其可谓精通，自然是知道，所谓栈就是推崇后来者居上的数据结构。`lua_loadfile` 函数可将编译好的指令放在 Lua 栈的顶部。我们可以通过 `lua_pcall` 调用这个指令，便可让该指令对应的函数运转，即该函数中的变量得到定义，并且该函数所调用的函数也会得以运转。上述代码中的匿名函数，只是定义变量 `place`。

在 C 程序中，通过 `lua_pcall` 调用 Lua 栈顶指令的方式如下：

```c
if (lua_pcall(L, 0, 0, 0)) {
    fprintf(stderr, "lua_pcall error.\n");
    exit(EXIT_FAILURE);
}
```

`lua_pcall` 的第 2 个参数表示 Lua 栈顶前 n 个元素是 `lua_pcall` 要调用的函数所需的参数，第 n + 1 个元素是要调用的函数，n 为 0，表示函数无参数，故而函数便位于栈顶。`lua_pcall` 的第 3 个参数表示所调用的函数的返回值个数，这些返回值也会被放在栈顶，供调用者取用。`lua_pcall` 的第 4 个参数是出错函数的索引，用于指示 `lua_pcall` 执行过程中出错，该调用哪个错误处理函数。若只考虑载入 Lua 脚本这一任务，通常将 `lua_pcall` 的后三个参数皆设为 0 即可。

需要注意的是，Lua 语言对于变量的定义有一个默认规则，若变量定义没有任何修饰，则意味着所定义的变量是全局变量，故而上述代码中的 `place` 变量虽然是在一个匿名函数中定义的，但它是全局变量。在 Lua 语言中，若需要局部变量，则必须用 `local` 修饰，例如

```lua
local place = "小沛"
```

倘若上述代码出现在 foo.lua 里，即使被 Lua 解释器加载，我们也无法访问 `place` 的值。

## 虚拟栈

我们创建的 Lua 解释器，在成功载入 foo.lua 文件并执行了包裹该文件全部内容的匿名函数之后，如何访问该文件中定义的数据呢？

在 foo.lua 文件里，定义了一个变量 `place`。上文说过，在 Lua 语言中，若一个变量，没有任何修饰，它便是全局变量。在 C 程序里，可以通过 `lua_getglobal` 获取指定名字的全局变量的值。例如，要获取 `place` 这个全局变量的值，只需

```c
lua_getglobal(L, "place");
```

可是，`place` 这个变量的值，在哪里呢？在 Lua 栈顶。`lua_getglobal` 函数会将获取的变量的值放在 Lua 栈的顶部。`place` 的值，其类型在 C 程序中只能是字符串类型，可以使用 `lua_tostring` 函数从栈顶获取字符串数据，例如

```c
const char *place = lua_tostring(L, -1);
printf("新手村: %s\n", place);
```

上述代码中的 `-1` 是 Lua 栈的栈顶元素的索引。Lua 栈的元素索引规律是，从栈底向上，元素的索引是从 1 开始自然递增。若是从栈顶向下，元素的索引是从 -1 向下自然递减。

然后，使用 `lua_pop` 函数将栈顶元素弹出，亦即删除栈顶元素，让原来栈顶的第 2 个元素作为新的栈顶元素。`lua_pop` 可以弹出栈顶的前 n 个元素，如果我们只需要弹出栈顶元素，即 n 为 1，只需

```c
lua_pop(L, 1)
```

以上便是 Lua 栈的最为基本的用法。理解了 Lua 栈，便把握了在 C 程序与 Lua 解释器之间的协作机制。

下面给出完整的解析 foo.lua 的代码：

```c
/* foo.c */
#include <stdio.h>
#include <stdlib.h>
#include <lua.h> 
#include <lauxlib.h>
#include <lualib.h>

int main(void) {
    lua_State *L = luaL_newstate(); 
    luaL_openlibs(L);
    if (luaL_loadfile(L, "foo.lua")) {
        fprintf(stderr, "failed to load lua script.\n");
        exit(EXIT_FAILURE);
    }
    if (lua_pcall(L, 0, 0, 0)) {
        fprintf(stderr, "lua_pcall error.\n");
        exit(EXIT_FAILURE);
    }

    /* 获取 place 的值 */
    lua_getglobal(L, "place");
    const char *place = lua_tostring(L, -1);
    printf("新手村: %s\n", place);
    lua_pop(L, 1);

    lua_close(L);
    return 0;
}
```

## 新手村

将 foo.lua 内容修改为

```lua
--[[
新手村: 
  地名: 小沛
  村长: 刘备
]]
novice_area = {
    place = "小沛",
    mayor = "刘备"
}
```

上述代码中使用了 Lua 语言的多行注释语法，即

```lua
--[[
... ... ...
]]
```

而且为了用中文表达 Lua 的数据结构的含义，我们用 YAML 的映射结构作为注释。

foo.lua 文件里的 `novice_area` 是 Lua 表结构。因为你对 C 熟悉，可以将其理解为以下结构体形式：

```c
struct {
    place;
    mayor;
} novice_area = {"小沛", "刘备"};
```

## 表结构解析

假设 foo.lua 已被 `lua_load_file` 载入，且通过 `lua_pcall` 令其内容生效，在这一前提下，可通过 `lua_getglobal` 函数获得 `novice_area`。

由于 `novice_area` 是 Lua 表，而在 C 语言里，没有可与之直接对应的数据类型，故而只能逐一获取表中数据。

在 C 程序中，查询 Lua 表中的数据，可用 `lua_gettabel` 函数。对于 `novice_area` 表，若是在 Lua 语言里，获取其中的数据，例如 `mayor` 的值，只需

```lua
novice_area["mayor"]
```

或

```lua
novice_area.mayor
```

上述语句所得到的值是 `刘备`。但是，`lua_gettable` 函数要获得 `mayor` 对应的值，前提是需要我们将 `"mayor"` 这个键名压入 Lua 栈，即

```lua
lua_pushstring(L, "mayor");
```

你需要注意的是，在将 `"mayor"` 压入 Lua 栈之前，栈顶元素是 `novice_area` 表。一旦 `"mayor"` 入栈，那么栈顶元素就是 `"mayor"` 字符串了，其索引为 -1，而 `novice_area` 则屈居于栈顶第 2 个元素，其索引变为 -2 了。理解这一点，便是掌握 Lua 栈的关键。

`lua_gettable` 函数可将栈顶元素的字符串作为键名，从指定的 Lua 表中查询相应的值。如何指定 Lua 表呢，依然是通过 Lua 栈的索引。例如

```c
lua_gettable(L, -2);
```

索引 -2 便是 `novice_area` 表。`lua_gettable` 会将查询结果放在栈顶，覆盖原有的栈顶元素。要获得栈中的数据，需要使用一组 `lua_to` 函数。例如，`mayor` 的值是 `刘备`，从 C 程序角度看，这个值应该是字符串，故而可用 `lua_tostring` 从栈顶获得这个字符串：

```c
const char *mayor = lua_tostring(L, -1);
```

常用的从 Lua 栈中获取数据的函数还有 `lua_tonumber`，`lua_tointeger` 以及 `lua_toboolean`，它们分别用于获取实数、整数以及布尔值。

如此便完成了从 `novice_area` 表中查询相应数据的过程，最后用 `lua_pop` 将栈顶元素弹出，让 `novice_area` 重回栈顶，等待下一次的查询。

```c
lua_pop(L, 1)
```

基于上述知识，我们能够在 C 程序里完成 foo.lua 中 `novice_area` 表的解析，以下是关键代码：

```c
/* 获取 novice_area 表 */
lua_getglobal(L, "novice_area");
printf("新手村: \n");

/* 获取 place 的值 */
lua_pushstring(L, "place");
lua_gettable(L, -2);
const char *place = lua_tostring(L, -1);
printf("  地名: %s\n", place);
lua_pop(L, 1);

/* 获取 mayor */
lua_pushstring(L, "mayor");
lua_gettable(L, -2);
const char *mayor = lua_tostring(L, -1);
printf("  村长: %s\n", mayor);
lua_pop(L, 1);

/* 弹出 novice_area */
lua_pop(L, 1);
```

Lua 库为了简化从表中获取数据的代码，提供了 `lua_getfield` 函数，其用法如下：

```c
lua_getfield(L, -1, "mayor");
```

上述代码等效于

```c
lua_pushstring(L, "mayor");
lua_gettable(L, -2);
```

**练习**：如果将 foo.lua 的内容修改为以下形式，你知道如何解析它吗？

```lua
--[[
新手村: 
   地名: 小沛
   位置: [x: 32, y: 40]
   村长: 刘备
]]
novice_area = {
   place = "小沛",
   location = {x = 32, y = 40},
   mayor = "刘备"
}
```

## 类型检测

为了让数据解析过程更为安全，Lua 库提供了一组类型检测函数，它们可用于判定 Lua 栈中的元素是否为某种类型。例如，`lua_istable` 可以判定栈中元素是否为 Lua 的表类型，其用法如下：

```c
lua_getglobal(L, "novice_area");
if (!lua_istable(L, -1)) {
    fprintf(stderr, "*novice_area* is not table.\n");
    exit(EXIT_FAILURE);
}
```

`lua_istable` 根据 Lua 栈的索引判断栈中某个元素的类型是否为表，若是，则返回非 0，否则返回 0。其他常用的类型检测函数有 `lua_isnumber`，`lua_isstring` 和 `lua_isnil`，分别用于检测栈中元素是否为数字、字符串和 Lua 的空值。

## 中文键名

实际上，是有办法让 Lua 表支持以中文作为键名，只是形式上会让配置文件不够优雅。例如，我们像下面这样定义 `novice_area` 表：

```lua
novice_area = {
    ["地名"] = "小沛",
    ["村长"] = "刘备"
}
```

表中元素的键可以用中文，但是表变量还不可以。不过，Lua 语言的全局变量皆在一个名为 `_G` 的表中，故而我们可以直接向这个表里塞入以 `新手村` 为键的表，即

```lua
_G["新手村"] = {
    ["地名"] = "小沛",
    ["村长"] = "刘备"
}
```

在 C 程序中使用 Lua 解释器获取上述表时，便可用中文为键，例如

```c
lua_getglobal(L, "新手村");
printf("新手村: \n");

lua_getfield(L, -1, "地名");
const char *place = lua_tostring(L, -1);
printf("  地名: %s\n", place);
lua_pop(L, 1);

lua_getfield(L, -1, "村长");
const char *mayor = lua_tostring(L, -1);
printf("  村长: %s\n", mayor);
lua_pop(L, 1);

lua_pop(L, 1);
```

## 总结

基于 Lua 栈，将 Lua 数据解析为 C 对象的过程并不复杂，前提是你的心里要对 Lua 栈的运作机制建立清晰的图像。对于 C 程序员而言，理解这种机制可能并不困难，原因是，C 函数本身就是基于栈机制工作的。每当我们调用一个 C 函数时，都会有参数和返回地址入栈的一系列操作，只是这些操作发生在 CPU 层面，而且 C 编译器帮助我们将这个过程隐匿了起来，即便如此，熟悉这种栈机制，也是广大 C 开发者的常识。有些开发者不熟悉 C，可能会觉得这种机制颇为原始。

在初步掌握 Lua 数据解析的过程中，我还发现了一件有趣的事实。很多人对 Lua 全局变量语法提出了相当严厉的批判，只是因为他们从未考虑要用 Lua 语言作为软件的配置语言，而这一任务恰好是 Lua 语言最初发明时的主要动机。倘若不将变量默认为全局变量，那么作为软件的配置文件使用的 Lua 脚本里只能出现一堆使用类似 `global` 这样的单词修饰的变量定义了。

实际上，将变量默认为全局的，不止 Lua，像 Bash 之类的 Shell 语言，它们的变量默认也是全局的。还有 Emacs Lisp，它的变量也是全局的，而且 Emacs 用 Emacs Lisp 作为配置语言。从这一点来说，Lua 像一个没有重重括号的 Emacs Lisp。