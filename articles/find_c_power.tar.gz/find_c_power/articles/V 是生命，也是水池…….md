---
id: "2018860687905039815"
title: "V 是生命，也是水池……"
author: "李缓慢"
type: zhihu-article
source: "https://zhuanlan.zhihu.com/p/2018860687905039815"
created: "2026-03-22 02:56"
downloaded: "2026-03-22"
---
在「[类型、回调函数及二阶多态](https://zhuanlan.zhihu.com/p/2018639929069057524)」里，我定义了一个函数 `wk_free`，它具备释放任何一个盒子及其所存之物的能力。 任何人若需要使用 `wk_free` 支持自己定义的一些数据类型，只需在该类型对象的构造函数中，使用 `wk_free_bus_connect`，将释放函数及其相关类型写入 `_wk_free_bus_` 的某个槽位。

与直接让 `wk_free` 支持回调函数的方式 相比，上述方式虽然有些繁琐，但它使得实现更高层次的抽象变为可能。例如，基于盒子与 `wk_free` 可以建立一套简易的内存半自动回收机制，它能回收在堆空间里分配的任意类型的对象，前提是需要手工对该对象作出「标记」——想要全自动的内存回收机制，可以用 Bohem GC 库。

下面，我将以推导或画画的方式逐步为你勾画出这套内存半自动回收机制的模样，最终可得到一个名为 WkV 的模块，V 是 Vita，生命的意思。我之所以用如此简写的名字，是为了这套内存回收机制相应的函数和宏在代码里显得简洁和醒目一些。

这套内存回收机制的原理非常简单，在创建任何对象后，只需让对象（确切地说，是指向对象的指针）穿过函数 `WK_V`，后者会将其记录在全局数组 `_wk_global_boxes_` 里，然后再将对象直接返回。完成这个过程后，意味着这个对象的所有权移交给了内存回收机制，便不可再手工调用其释放函数或交由 `wk_free` 予以释放了。

全局数组 `_wk_global_boxes_` 的容量可以无限制的增长，但是它受阈值 `_wk_global_boxes_n` 的约束，该阈值默认是 1024。在检测到数组容量超限时，会释放多出的部分。检测时机是在每次对数组内的对象完成一轮清除之后。

显然， `_wk_global_boxes_` 每一轮的清除过程里，不能一次性释放所有对象，因为函数可能会存在嵌套调用，故而 `_wk_global_boxes_` 必须是栈结构。

可以将 `_wk_global_boxes_` 理解成水池，每个函数都会向其注水。当函数 A 调用了函数 B 时，在函数 B 中必须要记录水池当前的水位线，然后再向其注水，在函数 B 退出时，基于所记录的水位线，将 B 注入的水释放出来。为了模拟这种过程，必须再设立一个全局变量，用于记录水池每个时刻的水位线，这个全局变量我用 `_wk_global_scope_` 表示。

基于上述设计，现在便可写出 `WK_V` 函数：

```c
/* wk-v.h */
#define _wk_global_boxes_n_ 1024
extern size_t _wk_global_scope_;
extern WkArray *_wk_global_boxes_;

/* wk-v.c */
size_t _wk_global_scope_ = 0;
WkArray *_wk_global_boxes_ = NULL;

void *WK_V(void *obj, size_t u, const char *type) {
        WkBox *box = WK_BOX(&obj, u, type);
        if (!_wk_global_boxes_) _wk_global_boxes_ = wk_array(WkBox *);
        if (_wk_global_scope_ < _wk_global_boxes_->n) {
                wk_array_put(_wk_global_boxes_, _wk_global_scope_, box, WkBox *);
        } else wk_array_add(_wk_global_boxes_, box, WkBox *);
        _wk_global_scope_++;
        return obj;
}
```

`WK_V`可向水池里注入一滴水，它会先检测水池当前容量是否够用，若够用，直接注水，否则扩大水池再注水。待注水工作完成后，水位线也相应增 1。

对于希望使用水池的每个函数，在一开始时，需要用一个局部变量记录当前的水位线，然后方能向其中注水。可以定义一个宏来完成水位线记录工作：

```c
/* wk-v.h ++ */
#define wk_v_begin \
        size_t _wk_local_scope_ = _wk_global_scope_
```

使用了水池的函数，在退出时，必须释放它在池中所注入的那部分水，这个过程用宏 `wk_v_end` 来表达：

```c
#define wk_v_end do { \
        /* 释放对象 */ \
        while (1) { \
                wk_free(wk_array_get(_wk_global_boxes_, \
                                     _wk_global_scope_ - 1, \
                                     WkBox *)); \
                _wk_global_scope_--; \
                if (_wk_global_scope_ == _wk_local_scope_) break; \
        } \
} while (0)
```

`wk_v_end` 的工作很简单， 它会释放水池中新加入的对象，直至全局水位线回退到函数刚进入时所记录的值，这个过程当然可以用函数来实现，可是为了能够与 `wk_v_begin` 构成对称形式，我还是决定用宏。

那么何时检测水池超出阈值 `_wk_global_boxes_n_` 并缩减其容量呢？就在 `wk_v_end` 释放对象过程之后，亦即上述 `wk_v_end` 的定义并不完整，还需要增加缩容过程，故而完整的 `wk_v_end` 定义如下：

```c
#define wk_v_end do { \
        /* 释放对象 */ \
        while (1) { \
                wk_free(wk_array_get(_wk_global_boxes_, \
                                     _wk_global_scope_ - 1, \
                                     WkBox *)); \
                _wk_global_scope_--; \
                if (_wk_global_scope_ == _wk_local_scope_) break; \
        } \
        /* 缩容 */ \
        if (_wk_global_boxes_->n > _wk_global_boxes_n_ \
            && _wk_global_scope_ < _wk_global_boxes_n_) { \
                while (_wk_global_boxes_->n > _wk_global_boxes_n_) { \
                        wk_array_del(_wk_global_boxes_, _wk_global_boxes_->n - 1); \
                } \
        } \
} while (0)
```

注意，在缩容部分，必须保证，缩容之后水池不会使池中尚存之水溢出，这就是缩容时一开始的条件判断语句所要达成的目的，不满足这个条件，便暂时不对水池缩容。

至此，这套半自动的内存回收机制便完成了。下面的示例可以表达其基本用法：

```c
void foo(void) {
        wk_v_begin;
        WkStr *a = WK_V(wk_str("hello"), sizeof(WkStr *), "WkStr *");
        WkStr *b = WK_V(wk_str("world!"), sizeof(WkStr *), "WkStr *");
        wk_v_end;
}

void bar(void) {
        wk_v_begin;
        WkStr *a = WK_V(wk_str("HI"), sizeof(WkStr *), "WkStr *");
        foo();
        WkStr *b = WK_V(wk_str("WORLD!"), sizeof(WkStr *), "WkStr *");
        wk_v_end;
}
```

显然，`WK_V` 的用法有些繁琐，故而为其定义便于使用的宏形式：

```c
/* wk-v.h ++ */
#define wk_v(obj, T) WK_V(obj, sizeof(T), #T)
```

于是，上述示例便可简化为

```c
void foo(void) {
        wk_v_begin;
        WkStr *a = wk_v(wk_str("hello"), WkStr *);
        WkStr *b = wk_v(wk_str("world!"), WkStr *);
        wk_v_end;
}

void bar(void) {
        wk_v_begin;
        WkStr *a = wk_v(wk_str("HI"), "WkStr *);
        foo();
        WkStr *b = wk_v(wk_str("WORLD!"), WkStr *);
        wk_v_end;
}
```

倘若还是觉得这种移交所有权的语句有些繁冗，可以在 WkStr 模块里定义特化宏：

```c
#define wk_v_str(raw) wk_v(wk_str(raw), WkStr *)
```

于是，上述示例代码可再度简化为

```c
void foo(void) {
        wk_v_begin;
        WkStr *a = wk_v_str("hello");
        WkStr *b = wk_v_str("world!");
        wk_v_end;
}

void bar(void) {
        wk_v_begin;
        WkStr *a = wk_v_str("HI");
        foo();
        WkStr *b = wk_v_str("WORLD!");
        wk_v_end;
}
```

请记住，**宏是可以勇敢使用的，但前提是，你需要先写出许多繁冗的代码，直到自己不胜其烦之时，便可以用宏去作简化了**。为何如此强调要先写繁冗的代码呢？因为这些代码本身就是宏在你大脑里的展开结果，当你对它的展开足够熟悉时，自然就知道如何定义这个宏了。

若是在函数里引入「[一种关于 C 程序错误的哲学](https://zhuanlan.zhihu.com/p/2017649359882318343)」所述的错误处理机制，则 `wk_v_end` 需要与 `return` 结合，也需要与错误兜底宏 `wk_fallback` 与 `wk_fallback_with` 宏结合，故而可再定义以下宏：

```c
#define wk_v_ret(val) wk_v_end; return val;
#define wk_v_fallback wk_v_end; return; wk_err_report;
#define wk_v_fallback_with(val) wk_v_end; wk_err_report; return val;
```

例如，下面的函数是有返回值的函数，需要保证函数的正确返回点与错误返回点都需要回收内存，则上述定义的宏 `wk_v_ret` 和 `wk_v_fallback_with` 可以保证内存回收过程正常执行。

```c
int foo(void *data) {
        wk_v_begin;
        if (!data) wk_err("invalid data");
        WkStr *a = wk_v_str("hello");
        wk_v_ret(42); /* 正确返回点 */
        wk_v_fallback_with(42); /* 错误返回点 */
}
```

对于无返回值的函数，若需要错误处理机制，只需要用 `wk_v_fallback` 兜底即可，例如

```c
void bar(void) {
        wk_v_begin;
        WkStr *a = wk_v_str("HI");
        if (foo() != 42) wk_err("宇宙秘密何在？");
        wk_v_fallback;
}
```

注意，在某个函数里，忘记在进入时写 `wk_v_begin` 是致命的，代码会无法通过编译，并且你可能不知道哪儿出错了，编译器会说 `wk_v_end` 处有问题。如果在某个函数退出时，忘记用 `wk_v_end` 放水，则不会致命，只是会泄露部分内存。