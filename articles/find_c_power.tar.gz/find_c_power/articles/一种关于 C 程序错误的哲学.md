---
id: "2017649359882318343"
title: "一种关于 C 程序错误的哲学"
author: "李缓慢"
type: zhihu-article
source: "https://zhuanlan.zhihu.com/p/2017649359882318343"
created: "2026-03-18 18:57"
downloaded: "2026-03-22"
---
此刻，想必你已经通过「[C 语言初学者，请和我一起写字符串模块吧！](https://zhuanlan.zhihu.com/p/2017058188965459813)」这篇文章学会了 C 语言……或者我谦虚一些，你已经知道了 C 程序的大致模样——在内存的世界里走钢丝的杂技演员。该文有一个小节，讲述了如何基于 C 语言的 `goto` 语法为函数构造错误处理机制，本文试图让该小节变得宏大一些。

倘若你从未看过上述的这篇文章，而且也压根不打算去看，那么我可以略作剧情回顾。假设有一个 C 函数 `foo`，其伪代码如下：

```c
void *foo(void *input) {
        const char *err = NULL;
        if (!input) {
                err = "input 无效";
                goto ERROR;
        }
        foo 函数的主体部分，有一些环节,
        if (有错误) {
                err = "这是个什么错误";
                goto ERROR;
        }
        可能会有许多上述这样的错误检测语句;
        return 正确的结果;
ERROR:
        fprintf(stderr, "%s: %s!\n", __func__, err)
        return NULL; /* 返回错误的结果 */
}
```

亦即，`foo` 函数基于 `goto` 语法，将 `foo` 函数所有可能出现的错误，在函数末尾作统一处理。这种方式的好处是，函数只需要有两处返回点，一处表示正确，一处表示错误。

函数正确的返回点，可以视为一部电器正常的输出，其错误的返回点，你不妨将其视为与地线的连接点，不过，它不是在保护程序的安全，而是保护开发者的安全，以避免他们无能狂怒，而闹出一些匪夷所思的动静。

有时，函数正确的返回点与错误的返回点，返回的结果可能是一样的，例如上述的 `foo` 函数，在正确的返回点也有可能返回 `NULL`，但两者的区别是，错误的返回点会伴随程序的报错。

上述便是我最近对 C 程序的错误而构造的新的哲学……之所说它是哲学，原因是，科学不是用来处理错误的，而是用来发现正确。

不过，肯定不是什么重大发现，而且也一定早已有许多人这样思考过，只是他们大概早已不用 C 了吧……我依然在用，而且盘算着如何使之宏大。宏大的意思是，用 C 语言的宏，使之大放光彩，即便那只是摇曳的烛光，也能照亮和温暖我的寒舍。

首先，我构造了一个全局变量作为地线：

```c
/* wk-err.h */
extern const char *_wk_err_;

/* wk-err.c */
const char *_wk_err_ = NULL;
```

然后，定义第一个宏：

```c
/* wk-err.h ++ */
#define wk_err(E) do { \
        _wk_err_ = E; \
        goto _WK_ERROR_; \
} while (0)
```

这个宏只是记录错误，并跳转到函数的错误返回点。

第二个宏用于报错，其定义如下：

```c
/* wk-err.h ++ */
#define wk_err_report \
_WK_ERROR_: \
        if (_wk_err_) { \
                fprintf(stderr, "%s: %s\n", __func__, _wk_err_); \
                _wk_err_ = NULL; \
        }
```

第三个宏，用于无返回值的函数，其定义如下：

```c
/* wk-err.h ++ */
#define wk_fallback return; wk_err_report;
```

第四个宏，用于有返回值的函数，其定义如下：

```c
/* wk-err.h ++ */
#define wk_fallback_with(v) wk_err_report; return v;
```

在写程序时，只需要使用 `wk_err`、`wk_fallback` 以及 `wk_fallback_with` 这三个宏，其中后两者，顾名思义，其作用是为函数兜底，故而在使用时，一定要将其置于函数最后的位置。下面举两个例子，阐述这三个宏的用法。

第一个例子是，在无返回值的函数里，`wk_err` 和 `wk_fallback` 如何构成一套错误处理机制，如下：

```c
void wk_str_free(WkStr *str) {
        if (!str) wk_err("invalid WkStr object");
        free(str->body);
        free(str);
        wk_fallback;
}
```

上述代码，当 `str` 为 `NULL` 时，`wk_err` 会记录错误信息，然后跳转到 `wk_fallback` 语句。

第二个例子是，在有返回值的函数里，`wk_err` 和 `wk_fallback_with` 如何构成一套错误处理机制，如下：

```c
void *wk_box_as(WkBox *box, size_t size, const char *type) {
        if (!box) wk_err("invalid WkBox object");
        /* 类型检测 */
        if (!wk_is(box, type) && !wk_is(box, "void *")) {
                wk_err("type not matched");
        }
        if (box->size < size) { /* 取数据时，长度可以小于盒子里数据的长度 */
                wk_err("size not matched");
        }
        return box->body;
        wk_fallback_with(NULL);
}
```

上述代码中，当 `wk_err` 被触发时，它会记录错误信息，然后跳转至 `wk_fallback_with` 语句，后者会报错，然后返回 `NULL`。

这套哲学会在错误信息需要格式化时失效，若遇到这种情况，可回归其本体，例如：

```c
WkStr *wk_str_from_file(const char *path) {
        FILE *f = fopen(path, "r");
        if (!f) goto ERROR;
        WkStr *buffer = wk_str(NULL);
        /* 将文件内容逐字符（char 类型）存入 buffer */
        int c;
        while ((c = fgetc(f)) != EOF) {
                wk_str_suffix_char(buffer, (char)c);
        }
        return buffer;
ERROR:
        fprintf(stderr, "%s: failed to open %s!\n", __func__, path);
        return NULL;
}
```

关于这个哲学，有一道思考题，即 `wk_err(NULL)` 意味着什么？ 应该是一种介于正确和错误之间的东西。