---
id: "2017058188965459813"
title: "C 语言初学者，请和我一起写字符串模块吧！"
author: "李缓慢"
type: zhihu-article
source: "https://zhuanlan.zhihu.com/p/2017058188965459813"
created: "2026-03-17 10:36"
downloaded: "2026-03-22"
---
## 前言

现在，倘若你正在或计划学习 C 语言，无论你是计算机编程的初学者，还是已经掌握了某种其他编程语言的人，想必早已从江湖上各路先知那里大概了解到 C 语言几乎什么都没有……没有字符串、动态数组、链表、散列表、树、图……没有面向对象，没有泛型，没有异常，没有 Lambda 函数，没有垃圾内存回收……

在此，我有暴论，学习 C 语言，你一人足矣，但学习 C++、Java、C#、Rust ……这些工业级别的语言，你需要在一个团队里，原因是，一门语言，若它什么都有，并非个人的需要，而是团队协作的需要。网上有许多人在评价语言高低优劣时，往往会忘记自己身后的团队，而以为是自己一人之力所获的洞察，也许是另一种身份的楚门……对于他们，我毫无贬低之意，这一点，与他们对 C 的态度截然不同。

如果你像我一样，在漫长的时间里，没有团队，但是心里却有一些想要创造的软件，或者想了解编程这门技艺，C 语言依然适合你……毕竟当初创造 Unix 也只需要两个人。

C 语言里什么都没有，实际上反而是你最好的学习编程的途径。例如，在 C 语言所没有的这些东西里，最简单的事物是字符串。当你能写出一个字符串模块，就意味着你已经入了 C 编程之门。当你能用 C 写出函数的运行时多态，就意味着那些什么都有的语言，在你面前也无奥妙可言。你能在这条路上走多远，取决于你是否将这个活动视为游戏。若你觉得这个游戏还不错，那么无需犹豫，请和我一起来写这个字符串模块吧！

## 一些准备

学习 C 语言，最好的环境是 Linux。世上有很多 Linux，但无论你选择哪一种，通常它都具备 C 语言编程环境。很多人抱怨，Linux 里没有好用的 IDE（集成式开发环境），实际上 Linux 本身便是绝好的 C 语言 IDE。

很多年前，我用的 Linux 是 Gentoo，用了许多年，但这几年，台式机上用的是 Mint，笔记本里用的是 Ubuntu。我不是在卖弄我用过很多 Linux，只是想告诉你，它们只是安装过程有所区别，但是用起来，特别是写 C 程序这件事，是完全一样的。

C 语言编译器，我用的是 gcc，但你也可以用 clang，只是在本文以及后续文章里，我给出的编译命令都是 gcc。

C 代码编辑器，我用的是 Emacs，你也可以用任何其他的编辑器。不过，倘若你也想用 Emacs，但不知从何学起，你可以参考我的一条学习路线：

[https://www.zhihu.com/column/c_1629547887418941440](https://www.zhihu.com/column/c_1629547887418941440)

基本的 C 开发环境只需要这些东西。当然，即使你在 Windows 里，并不愿意使用 Linux，也可以在 Windows 的 Linux 子系统里学习 C，只是我对此并不了解，没法提供帮助。

如果我成功说服了你使用 Linux 作为 C 编程环境，那么你需要想办法学会如何打开终端，以及如何在其中键入命令并执行，这些知识并不难，三五分钟就掌握了，现在有 AI，不懂可直接问它。即使你不知如何打开终端，只需要告诉 AI 你用的 Linux 是哪一种，它会告诉你许多办法。

## 理解 C 字符串

说 C 语言没有字符串，是不客观的，它有字符串，甚至 C 标准库里已经为其提供了近乎完备的功能。只是 C 字符串在形式上是指针，例如

```c
char *s = "Hello world!";
```

你需要将 `s` 理解为，它是 `char` 指针，指向内存里用于存放字符串本体的一段空间的起点。若你对指针并不熟悉，你需要将指针「指向」某物，直接理解为，指针的值是某物的地址。上述语句的右侧（在 C 的术语里，即右值）是 C 字符串本体，它位于内存某处，你无法直接访问它，只能 `char` 指针。

计算 C 字符串的长度，可以直接用 C 标准库提供的 `strlen` 函数。下面这个完整的 C 程序，演示了 `strlen` 的用法：

```c
/* foo.c */
#include <stdio.h>
#include <string.h>
int main(void) {
        char *s = "Hello world!";
        size_t n = strlen(s);
        printf("%s: %lu 字节\n", s, n);
        return 0;
}
```

使用 gcc 编译上述源码文件 foo.c 并运行所得程序的命令如下：

```c
$ gcc foo.c -o foo
$ ./foo
Hello world!: 12 字节
```

程序 foo 的输出，与 `"Hello world!"` 的字符数量是相同的，共 12 个字符，包括那个空格，每个西文字符占 1 个字节。作为练习，你不妨将字符串的内容换成中文，再试试看。

一个令很多初学者，甚至颇有经验的人也偶尔会翻车的陷阱是，C 字符串的末尾有一个不可见的额外字节，它存储的字符是 `'\0'`。注意，在 C 语言里，字符串用双引号表达，字符则用单引号表达。这个额外的字节便是 C 字符串的结束符。利用这个字符，你可以写出自己的 `strlen`，例如

```c
size_t my_strlen(char *s) {
        size_t n = 0;
        for (char *p = s; *p != '\0'; p++) n++;
        return n;
}
```

倘若你向 `my_strlen` 或者 `strlen` 传入的指针，它所指向的空间没有 `'\0'` 作为结束符，程序就会出现未定义行为，对于这两个函数而言，输出的结果可能是正确的，但概率堪比彩票中奖。希望你能注意到，上述代码里，`*p` 表示对 `p` 所指内存空间取值。由于 `p` 的类型是 `char` 指针，故而从它指向的空间只能取出 `sizeof(char)` 个字节，亦即 1 个字节。

为了让你充分感受这一点，顺便给出 C 字符串的另一种形式——字符数组，看下面这个程序：

```c
#include <stdio.h>
#include <string.h>
int main(void) {
        char s[] = {'H', 'e', 'l', 'l', 'o'};
        printf("%s: %lu 字节\n", s, strlen(s));
        return 0;
}
```

它的输出极有可能是正确的，亦即

```c
Hello: 5 字节
```

可是，倘若将程序略微修改一下，如下

```c
#include <stdio.h>
#include <string.h>
int main(void) {
        char s[] = {'H', 'e', 'l', 'l', 'o'};
        char t[] = {'w', 'o', 'r', 'l', 'd'};
        printf("%s: %lu 字节\n", s, strlen(s));
        return 0;
}
```

则输出则变为

```text
Helloworld: 10 字节
```

这个例子足以让你感受到，没有结束符的字符串有多么可怕了。要修正上述程序，只需在字符数组的末尾增加 `'\0'`：

```c
char s[] = {'H', 'e', 'l', 'l', 'o', '\0'};
/* 或者 */
char s[] = "Hello";
```

虽然很少人会用字符数组的形式存储 C 字符串，但是许多实用性的程序，需要动态分配一段内存，用于存储字符串，而这段内存相当于字符数组。例如

```c
char *s = "Hello";
size_t n = strlen(s);
char *t = malloc(n);
for (size_t i = 0; i < n; i++) {
        t[i] = s[i];
}
```

此时，写代码的人可能会觉得已将 `s` 所指字符串完全复制到了 `t` 所指空间，此时便埋下了程序错误的种子。上述代码正确的写法是

```c
char *s = "Hello";
size_t n = strlen(s) + 1;
char *t = malloc(n);
for (size_t i = 0; i < n; i++) {
        t[i] = s[i];
}
```

若你理解了上述知识，对 C 的字符串就基本掌握了，最后你只需要知道，基于指针不仅能访问字符串，也能修改它，例如

```c
char *s = "Hello";
s[1] = 'E';     /* 试图将 Hello 改为 HEllo */
*(s + 1) = 'E'; /* 试图将 Hello 改为 HEllo */
```

上述两种修改 `s` 所指字符串的方式是等效的，它们都能通过 gcc 的编译，但是会导致程序出错，因为像 `"Hello"` 这样的字符串，称为字符串的字面量，它们是程序的一部分，位于一段特殊的内存区域——数据段或文本段，该区域中的数据通常可读，但不可修改，不过编译器无法检测代码里存在修改数据段只读区域的行为，除非编程者使用 `const` 修饰指针，表示指针所指之物是常量，其内容不许修改。例如，上述代码若改为

```c
const char *s = "Hello";
s[1] = 'E';     /* 试图将 Hello 改为 HEllo */
```

则 gcc 便可检测出这段代码试图修改指针所指之物，继而报错：

```text
foo.c:4:14: error: assignment of read-only location ‘*(s + 1)’
    4 |         s[1] = 'E';
```

不过，这个报错信息里，你应该也能看出，`s[1]` 实际上就是 `*(s + 1)`。

## 数据段、栈与堆

也许最能让 C 程序员津津乐道的基本知识是程序的内存布局了。我不想画图，也不想精确地描述这个布局，因为它依赖操作系统层次实现。从粗略的角度来说，你只需要知道一个程序，其内存空间可以不严肃地大致分为数据段、栈空间和堆空间。

C 程序里的全局变量、静态变量以及字符串的字面量——诸如 `"Hello world!"`——，它们都存放在数据段里，有些可以读写，有些只读不可写，至少字符串的字面量所在区域，肯定是只读区域，故而永远不要试图用指针去修改字符串的字面量。

哪些字符串空间是可以修改的呢？位于栈空间里的可以，亦即字符数组。回顾上文的一个例子：

```c
#include <stdio.h>
#include <string.h>
int main(void) {
        char s[] = {'H', 'e', 'l', 'l', 'o'};
        char t[] = {'w', 'o', 'r', 'l', 'd'};
        printf("%s: %lu 字节\n", s, strlen(s));
        return 0;
}
```

`s` 和 `t` 皆位于程序的栈空间，而且它们的区域是紧挨着的，故而在 `s` 没有字符串结束符时，`strlen` 能一路将 `t` 的区域也扫描了，而且 `printf` 也是如此，故而有了奇特的输出。

栈空间是有限的，在 Linux 系统里，程序的栈空间默认好像是 8MB 吧。栈空间的特点是，它是从内存的高地址空间向低地址空间发展的。函数的参数和函数内部的局部变量，皆位于栈空间。函数所拥有的栈空间通常称为栈帧，当一个函数调用了另一个函数时，后者的栈帧会在前者之上，但内存地址实际上是在前者之下。

要想得到清晰的栈空间图像，你需要让自己倒立，让天空为底，让大地为顶，函数的层层调用的栈帧像一个盘子向大地的方向摞起。当栈空间里的数据触底时，便会爆栈，程序彻底失控。**程序像一匹野马，栈空间相当于驾驭它的缰绳，紧握在我们手里，你最好不要让这缰绳断掉……**

堆空间的发展方向是符合我们常识的，从内存的低地址向高地址延伸，而且无有穷尽，就像野马纵横驰骋的大地——不过，这只是祖师爷图灵的想法。不过，现代的操作系统会让每个程序觉得自己能够拥有所有内存。此时，程序就像孟子，它会说，万物皆备于我。堆空间是一块大蛋糕，程序可以按需取用，不过吃了之后还是归还的，吃多少，还多少。C 标准库提供的 `malloc` 便是切蛋糕的工具，要切多大，由编程者给定，但是也不要乱切，否则你东一刀，西一刀，切得七零八落，等到需要切一大整块的时候，蛋糕剩下的已经不够了，即使之前切掉的都归还了，往往也很难再重新整合为大块。

我们要设计的字符串，叫作动态字符串，它位于堆空间，因为它需要生长。例如，一个字符串，可以从空字符串开始，逐渐长成庞然大物，像这篇文章一样的规模。

## 结构体

直接基于堆空间的动态分配机制和 `char` 指针，就可以实现动态字符串了，只是要想让它方便使用，可以将其生存期间所需的关键数据用结构体类型组织为一个整体，例如

```c
typedef struct {
        size_t n;
        char *body;
} String;
```

现在，你需要习惯这样定义结构类型。上述语句的含义是，用 `typedef` 将一个匿名的结构体类型

```c
struct {
        size_t n;
        char *body;
}
```

命名为 `String`。 在 C 编程中，`typedef` 非常有用，你需要熟悉并掌握它。

上述结构体里的字段（亦可称「成员」） `n` 用于记录字符串的长度，字段 `body` 指向字符串的本体——堆空间里的一段区域。

不过，将类型定义为 `String` 这样的名字，只有 C 语言的掌门级别的人才有资格如此自大。我们最好还是谦逊一些，给它加上前缀，通常以项目名称的简写作为前缀。我选择的前缀是 `wk`……我希望你别用它了，除非你比我还自大。`wk` 是 `walker` 的简写，但你也可以认为是孙悟空这个名字的简写 。于是，上述类型定义可改写为

```c
typedef struct {
        size_t n;
        char *body;
} WkStr;
```

是的，没必要写那么长，`String` 可以简写为 `Str`。

显然 `WkStr` 要比 `char` 指针更有用一些，因为基于前者，就无需在每次想获得字符串长度时，要重复执行 `strlen` 了。从现在开始，我们要有意识地培养一种直觉——需要频繁通过函数调用获取的信息，不妨设法将其记录在内存里，而结构体便是最好的记录工具，它像便笺，但是你最好将其视为生命体，只是样子像便笺。

## 构造函数

之所以希望你将结构体视为生命体，是因为要让它贴近面向对象编程中「对象」这一概念。从现在开始，可将 `WkStr` 类型的实例称为 WkStr 对象。

接下来，想必你会猜测，我要为 WkStr 对象写一个构造函数。 不过，在写这个构造函数之前，我希望你能够了解 C 语言的结构体类型，有三种实例化方式，虽然挺多，但依然比 C++ 类的实例化方式少了许多。下面以构造 0 个字节的空字符串为例，给出 `WkStr` 对象的三种构造方式。

第一种方式最为直白，例如

```c
WkStr a;
a.n = 0;
a.body = NULL;
```

或者

```c
WkStr a;
a.n = 0;
a.body = "";
```

亦即，当字符串长度为 0 时，我将 `a.body` 为 `NULL` 与空字符串视为等效。

第二种方式，称为复合字面量方式，例如

```c
WkStr a = {.n = 0, .body = NULL};
```

或者

```c
WkStr a;
a = (WkStr){.n = 0, .body = NULL};
```

第三种方式，称为列表式，最为简约，例如

```c
WkStr a = {0, NULL};
```

或者

```c
WkStr a;
a = (WkStr){0, NULL};
```

上述这三种方式，是在程序的栈空间里构造了 WkStr 对象。在栈空间里也能构造非空 WkStr 对象，例如

```c
WkStr a = {5, "Hello"};
```

然而，在实际的程序里，往往需要将许多 WkStr 对象在不同的函数里传来传去，栈空间里的对象无法满足该需求，必须在堆空间里创造 WkStr 对象，然后用栈空间里的指针去访问或改写它，例如

```c
WkStr *a = malloc(sizeof(WkStr));
a->n = 0;
a->body = NULL;
```

如果希望堆空间里的 WkStr 对象非空，可以像下面这样为其 `body` 字段分配内存并写入字符串数据：

```c
WkStr *a = malloc(sizeof(WkStr));
a->n = 5;
a->body = malloc(a->n + 1);
memcpy(a->body, "Hello", a->n + 1);
```

上述代码里的 `memcpy` 函数是 C 标准库函数，它的前两个参数皆为指针，分别指向目标地址和源地址， 该函数可将源地址里指定长度的数据复制到目标地址，故而上述 `memcpy` 可将 `"Hello"` 及其结束符复制到 `a->body` 所指地址。**一定不要忘记 C 字符串是有一个额外的字节用于存放结束符。**

> **小知识：在 Linux 里，可以用以下命令查阅 memcpy 函数的用法，当然也可以查询其他 C 标准库函数的用法。**

```text
$ man 3 memcpy
```

由于堆空间里构造的 WkStr 对象，只能通过栈空间里的指针访问和修改，故而如无特殊说明，可将该指针视为对象本身。故而上述代码里的 `a` 亦可称为 WkStr 对象。

结合上述讨论，便可写一个专门的函数，用于 `WkStr` 类型的实例化，例如

```c
WkStr *wk_str_new(const char *raw) {
        WkStr *str = malloc(sizeof(WkStr));
        size_t n = strlen(raw);
        str->n = n;
        str->body = malloc(n + 1);
        memcpy(str->body, raw, n + 1);
        return str;
}
```

对于一个 C 字符串——无论它是字面量，还是栈中的字符数组，还是堆空间里的字符串，`wk_str_new` 像是将其一个复本「提升」为 `WkStr` 对象了。不过，我不喜欢这个函数名，我觉得 `_new` 完全是行为艺术，我决定不要它，另外上述代码也缺乏对 `malloc` 分配内存失败时的情况予以处理，虽然这种情况在现代已经不太可能发生，但万一遇到，程序瞬间崩溃，而你却一时无从排错。重新定义的 WkStr 对象构造函数如下：

```c
WkStr *wk_str(const char *raw) {
        WkStr *str = malloc(sizeof(WkStr));
        if (!str) {
                fprintf(stderr, "wk_str error: "
                                "failed to create WkStr object !\n");
                return NULL;
        }
        size_t n = strlen(raw);
        str->n = n;
        str->body = malloc(n + 1);
        if (!str->body) {
                free(str);
                fprintf(stderr, "wk_str error: "
                                "failed to create WkStr object !\n");
                return NULL;
        }
        memcpy(str->body, raw, n + 1);
        return str;
}
```

从现在开始，你需要有意识的将错误视为程序的一部分，否则程序很容易就脱离你的掌控了。还 需要注意，上述语法利用了 C 字符串字面量的拼接技巧，亦即一些较长的字符串，若你想分行撰写，就可以用上述代码中的这种方式，亦即

```c
"wk_str error: "
"failed to create WkStr object !\n"
```

C 编译器会自动将连续的多个字符串字面量合并为一个。

## 释放函数

堆空间里的对象，通常有生必须有死，否则堆空间会很快被耗尽。事实上，无论你的机器上的内存有多大，我可以用下面这行代码在顷刻间将其彻底耗光：

```c
while (1) malloc(1024);
```

`malloc` 分配的空间，须由 `free` 函数释放，而且这两者的调用次数必须匹配，亦即调用了多少次 `malloc`，就必须调用多少次 `free`。

WkStr 对象的释放函数可定义为

```c
void wk_str_free(WkStr *str) {
        free(str->body);
        free(str);
}
```

每当函数写完后，我们就应该考虑，让它更安全一些，此时你需要做一个坏人，去想方设法让这个函数崩溃而且在其崩溃之前还无法向外部传达任何有价值的信息。

作为坏人，那么上述的 `wk_str_free` 不堪一击，只需要传给它 `NULL` 即可，亦即

```c
wk_str_free(NULL);
```

然后，`wk_free` 会在 `str->body` 处崩溃，因为当指针的值为 `NULL` 时，基于它取任何值都是非法的，只是编译器检测不出来，但程序运行时一定会崩溃，故而，`wk_str_free` 需要加固：

```c
void wk_str_free(WkStr *str) {
        if (!str) {
                fprintf(stderr, "wk_str_free error: "
                                "invalid WkStr object!\n");
                return;
        }
        free(str->body);
        free(str);
}
```

也许你会奇怪，为何不继续检测 `str->body` 呢？原因是，即使它为 `NULL`，`free` 函数不受影响，故而 `wk_str_free` 也不会被破坏，而且此时的 `str` 可能是空字符串，亦即，此时的 `wk_str_free` 能够兼容两种空字符串形式，一种是 `str->body` 指向空字符串，另一种是 `str->body` 为 `NULL`。

## 快照 1

现在，实际上已经有了一个字符串模块了，将其称为 WkStr 模块，它已牢牢攥住任何一个 WkStr 对象的生死。在此，我要给它拍几张特写照片。

首先，拍摄 WkStr 模块的颜面：

```c
/* wk-str.h */
#include <stdio.h>  /* 提供 fprintf 和 printf */
#include <stdlib.h> /* 提供 malloc */
#include <string.h> /* 提供 memcpy */

typedef struct {
        size_t n;
        char *body;
} WkStr;

WkStr *wk_str(const char *raw);
void wk_str_free(WkStr *str);
```

然后拍摄 WkStr 模块的躯体：

```c
/* wk-str.c */
#include "wk-str.h"

WkStr *wk_str(const char *raw) {
        WkStr *str = malloc(sizeof(WkStr));
        if (!str) goto ERROR;
        size_t n = strlen(raw);
        str->n = n;
        str->body = malloc(n + 1);
        if (!str->body) {
                free(str);
                goto ERROR;
        }
        memcpy(str->body, raw, n + 1);
        return str;
ERROR:
        fprintf(stderr, "wk_str error: "
                        "failed to create WkStr object !\n");
        return NULL;
}

void wk_str_free(WkStr *str) {
        if (!str) {
                fprintf(stderr, "wk_str_free error: "
                                "invalid WkStr object!\n");
                return;
        }
        free(str->body);
        free(str);
}
```

最后，拍摄 WkStr 模块摆的姿势……

```c
/* wk-str-test.c */
#include "wk-str.h"

int main(void) {
        WkStr *a = wk_str("Hello WkStr!");
        printf("a is \"%s\": %lu bytes.\n", a->body, a->n);
        wk_str_free(a);
        return 0;
}
```

以下命令可将这些照片冲洗出来：

```text
$ gcc wk-str.c main.c wk-str-test.c -o wk-str-test
$ ./wk-str-test
a is "Hello WkStr!": 12 bytes.
```

仅仅这样还是不够，我们需要验证照片是否存在破绽……验证工具便是 Linux 世界里大名鼎鼎的 valgrind，其用法如下

```text
$ valgrind --leak-check=yes ./wk-str-test
==19514== Memcheck, a memory error detector
==19514== Copyright (C) 2002-2022, and GNU GPL'd, by Julian Seward et al.
==19514== Using Valgrind-3.22.0 and LibVEX; rerun with -h for copyright info
==19514== Command: ./foo
==19514== 
a is "Hello WkStr!": 12 bytes.
==19514== 
==19514== HEAP SUMMARY:
==19514==     in use at exit: 0 bytes in 0 blocks
==19514==   total heap usage: 3 allocs, 3 frees, 1,053 bytes allocated
==19514== 
==19514== All heap blocks were freed -- no leaks are possible
==19514== 
==19514== For lists of detected and suppressed errors, rerun with: -s
==19514== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

当你看到 `0 errors` 就基本可以放心了。

## 宽容

目前，WkStr 对象依然是个榆木疙瘩，和 C 字符串并无本质区别，它无法与其他 C 字符串结合，从而实现自我更新，亦即它尚不具备开放性，很像那些内核颇为顽固的人，心里很难容得下自己世界之外的一切。

我们需要让 WkStr 对象更为宽容一些，让它像条贪吃蛇，当其首部遇到了 C 字符串，就将其作为自己新的首部，反之若其尾部遇到了 C 字符串，便将其作为自己新的尾部。于是，需要在 WkStr 里增加两个函数：

```c
/* sim-wk.h ++ */
void wk_str_prefix(WkStr *str, const char *raw);
void wk_str_suffix(WkStr *str, const char *raw);
```

在 sim-wk.c 里实现它们，我负责实现 `wk_str_prefix`，如下：

```c
/* sim-wk.c ++ */
void wk_str_prefix(WkStr *str, const char *raw) {
        size_t n = strlen(raw);
        char *new_body = realloc(str->body, str->n + n + 1);
        /* 将 new_body 中原有内容，向后移动 n 个字节 */
        for (size_t i = str->n - 1; i >= 0; i--) {
                str->body[i + n] = str->body[i];
        }
        /* 将 raw 的内容复制到 str->body 所指区域的前 n 个字节 */
        memcpy(str->body, raw, n);
        /* 更新字符串及其长度 */
        str->body = new_body;
        str->n += n;
        /* 不要忘记，new_body 所指空间需要以 `\0` 结尾 */
        str->body[str->n] = '\0';
}
```

> `realloc` 函数是 C 标准库函数，它可对指定的内存区域重新分配，将其原有长度扩展为指定长度，但原有内容不会发生变化，新增区域在原有区域之后。在此，我再啰唆几句，后续我可能还会引入一些 C 标准库函数，但对其只作简略描述，毕竟其用法已经体现在代码里了，若你需要了解更多信息不妨查手册，例如 `man 3 realloc`，或者问 AI……之后我就不再如此啰唆了。

然后，我满怀自信，将 wk-str-test.c 修改为

```c
#include "wk-str.h"

int main(void) {
        WkStr *a = wk_str("WkStr!");
        wk_str_prefix(a, "Hello ");
        printf("a is \"%s\": %lu bytes.\n", a->body, a->n);
        wk_str_free(a);
        return 0;
}
```

然后已经非常熟练的编译、运行……

```text
$ gcc wk-str.c wk-str-test.c -o wk-str-test
$ ./wk-str-test
Segmentation fault (core dumped)
```

如你所见，程序崩溃了，而且还是 C 世界里非常著名的错误——段错误（吐核）。毫无疑问，问题出在 `wk_str_prefix` 的定义里。 你可能希望我在此处开始写如何使用 gdb 调试程序，但是估计让你失望了，因为我没用过……

你惊呆了……你这么装逼，居然不会用 gdb？

没错，不会用。我会用 `printf` + 二分法，不过，这是我独门绝学，还是不传授了。实际上，只需要在编译代码时，给 gcc 命令加上 `-g` 选项，令其输出带有调试信息的编译结果：

```c
$ gcc -g wk-str.c wk-str-test.c -o wk-str-test
```

然后用 valgrind 便可定位错误，因为所有段错误，本质上是内存错误，而 valgrind 实际上是最好的调试器。我的试验结果如下：

```text
$ valgrind --leak-check=yes ./wk-str-test
$ valgrind --leak-check=yes ./foo
==28252== Memcheck, a memory error detector
... ... 省略了一些无关信息 ... ...
==28252== Invalid read of size 1
==28252==    at 0x1093A2: wk_str_prefix (wk-str.c:36)
==28252==    by 0x1093E3: main (main.c:5)
==28252==  Address 0x4a8a0df is 1 bytes before a block of size 25 alloc'd
==28252==    at 0x484DB80: realloc (in /usr/libexec/valgrind/vgpreload_memcheck-amd64-linux.so)
==28252==    by 0x109371: wk_str_prefix (wk-str.c:33)
==28252==    by 0x1093E3: main (main.c:5)
==28252== 
==28252== Invalid write of size 1
==28252==    at 0x1093A5: wk_str_prefix (wk-str.c:36)
==28252==    by 0x1093E3: main (main.c:5)
==28252==  Address 0x4a8a0df is 1 bytes before a block of size 25 alloc'd
==28252==    at 0x484DB80: realloc (in /usr/libexec/valgrind/vgpreload_memcheck-amd64-linux.so)
==28252==    by 0x109371: wk_str_prefix (wk-str.c:33)
==28252==    by 0x1093E3: main (main.c:5)
... ... 省略了一些无关信息 ... ...
==28252== ERROR SUMMARY: 416 errors from 2 contexts (suppressed: 0 from 0)
Segmentation fault (core dumped)
```

从 valgrind 的结果来看，首先你会看到错误的数量如此惊人。然后，可以看到 valgrind 给出了出错之处的函数调用栈，而且还给出了出错位置所在的代码行号：

```text
==28252== Invalid read of size 1
==28252==    at 0x1093A2: wk_str_prefix (wk-str.c:36)
==28252==    by 0x1093E3: main (main.c:5)
==28252==  Address 0x4a8a0df is 1 bytes before a block of size 25 alloc'd
==28252==    at 0x484DB80: realloc (in /usr/libexec/valgrind/vgpreload_memcheck-amd64-linux.so)
==28252==    by 0x109371: wk_str_prefix (wk-str.c:33)
==28252==    by 0x1093E3: main (main.c:5)
```

是 wk-str.c 的第 36 行出了问题，而这行代码是

```c
for (size_t i = str->n - 1; i >= 0; i--) {
```

你现在知道错在何处了吗？`size_t` 是无符号整型类型，故而 `i` 在递减到 0 时，再次递减，它也不会变成负数，而是会变成一个很大的正数，亦即这个 `for` 循环实际上永不停止。发现了问题，解决起来也非常容易，将 `i` 的类型更换为 `int` 或者 `ssize_t`，后者的长度与 `size_t` 相同，但支持负数。在此，你应该永远记住，循环变量递减时，若截止条件为 0，其类型永远不要用 `size_t`。若你坚持要走钢丝，也并非不可，只需像下面这样做：

```c
for (size_t i = str->n; i > 0; i--) {
        str->body[i + n - 1] = str->body[i - 1];
}
```

好了，现在轮到你去写 `wk_str_suffix`了，它比 `wk_str_prefix` 要简单一些，以至于你想犯我那个错误，都没机会。

当你写完 `wk_str_suffix` 之后，我们要做什么呢？当坏人！想方设法让 `wk_str_prefix/suffix` 崩溃。例如

```c
WkStr *a = wk_str("WkStr!");

 /* 会发生什么？ */
wk_str_prefix(a, "");

/* 会发生什么？ */
wk_str_prefix(a, NULL);

/* 会发生什么？*/
wk_str_prefix(NULL, "Hello");
```

将你害怕的或者担心的一切，都要尽力如实在 `wk_str_prefix/suffix` 函数里有所反映，这一切原本就是程序应该有的。最根本的原因是，你的害怕或担心原本也是你本体里一部分「代码」。由爱故生忧，由爱故生怖。害怕和担心，源于我们对这个世界还有很多热爱，因此它们是正常的，不害怕和不担心，反而很异常。

我为 `wk_str_prefix` 添加了一些害怕和担心：

```c
void wk_str_prefix(WkStr *str, const char *raw) {
        if (!str) {
                fprintf(stderr, "wk_str_prefix error: "
                                "invalid WkStr object!\n");
                return;
        }
        if (!raw || *raw == '\0') return;
        size_t n = strlen(raw);
        char *new_body = realloc(str->body, str->n + n + 1);
        if (!new_body) { /* 重新分配内存失败 */
                fprintf(stderr, "wk_str_prefix error: "
                                "memory not eough!\n");
                return;
        }
        /* 将 new_body 中原有内容，向后移动 n 个字节 */
        for (size_t i = str->n; i > 0; i--) {
                new_body[i + n - 1] = new_body[i - 1];
        }
        /* 将 raw 的内容复制到 new_body 所指区域的前 n 个字节 */
        memcpy(new_body, raw, n);
        /* 更新字符串及其长度 */
        str->body = new_body;
        str->n += n;
        /* 不要忘记，new_body 所指空间需要以 `\0` 结尾 */
        str->body[str->n] = '\0';
}
```

大概你会怀疑，添加这么多条件语句，岂不是让函数对 CPU 分支预测机制很不友好吗？那我应该怀疑你是在假冒 C 语言初学者……不过，不必担心，毕竟 `realloc` 和字符串复制，决定了这两个函数都不是追求高效性能的函数，多几条 `if/esle` 语句并不碍事，实际上其中有一条 `if` 语句能让函数提前返回，若其条件成立，倒是可以省却很多事情，你知道是哪条吗？

## 快照 2

wk-str.h：

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
        size_t n;
        char *body;
} WkStr;

WkStr *wk_str(const char *raw);
void wk_str_free(WkStr *str);

void wk_str_prefix(WkStr *str, const char *raw);
void wk_str_suffix(WkStr *str, const char *raw);
```

wk-str.c：

```c
#include "wk-str.h"

WkStr *wk_str(const char *raw) {
        WkStr *str = malloc(sizeof(WkStr));
        if (!str) goto ERROR;
        size_t n = strlen(raw);
        str->n = n;
        str->body = malloc(n + 1);
        if (!str->body) {
                free(str);
                goto ERROR;
        }
        memcpy(str->body, raw, n + 1);
        return str;
ERROR:
        fprintf(stderr, "wk_str error: "
                        "failed to create WkStr object !\n");
        return NULL;
}

void wk_str_free(WkStr *str) {
        if (!str) {
                fprintf(stderr, "wk_str_free error: "
                                "invalid WkStr object!\n");
                return;
        }
        free(str->body);
        free(str);
}

void wk_str_prefix(WkStr *str, const char *raw) {
        if (!str) {
                fprintf(stderr, "wk_str_prefix error: "
                                "invalid WkStr object!\n");
                return;
        }
        if (!raw || *raw == '\0') return;
        size_t n = strlen(raw);
        char *new_body = realloc(str->body, str->n + n + 1);
        if (!new_body) {
                fprintf(stderr, "wk_str_prefix error: "
                                "memory not eough!\n");
                return;
        }
        /* 将 new_body 中原有内容，向后移动 n 个字节 */
        for (size_t i = str->n; i > 0; i--) {
                new_body[i + n - 1] = new_body[i - 1];
        }
        /* 将 raw 的内容复制到 new_body 所指区域的前 n 个字节 */
        memcpy(new_body, raw, n);
        /* 更新字符串及其长度 */
        str->body = new_body;
        str->n += n;
        /* 不要忘记，new_body 所指空间需要以 `\0` 结尾 */
        str->body[str->n] = '\0';
}
```

wk-str-test.c：

```c
#include "wk-str.h"

int main(void) {
        WkStr *a = wk_str("WkStr");
        wk_str_prefix(a, "Hello ");
        wk_str_prefix(a, "");
        wk_str_prefix(a, NULL);
        wk_str_suffix(a, "!");
        printf("a is \"%s\": %lu bytes.\n", a->body, a->n);
        wk_str_free(a);
        return 0;
}
```

## 再宽容一些

`wk_str_prefix/suffix` 虽然能让 WkStr 对象活动起来，但是非常保守，每次扩容，只是刚好能容下要吞入的 C 字符串，如前文讲述堆空间时所言，此举很容易将堆空间切得七零八落，从而影响程序内存性能。

可以让这两个函数更为激进一些，例如，每当它们要吞入一个 C 字符串时，我们需要赋予它们一种期待，即可能下一次也要吞入这么长的 C 字符串，亦即每次在扩容时，可以基于当前要吞入的 C 字符串长度，适当多括一些空间。这个想法很好，但是会导致 WkStr 对象的 `n` 字段便不能反映 `body` 字段所指内存区域的长度了，必须在 `WkStr` 结构体里再增加一个字段 `m`，用于记录每次扩容后，`body` 所指内存区域的长度，亦即

```c
typedef struct {
        size_t n;  /* body 所指区域存储的字符串长度 */
        size_t m;  /* body 所指区域的长度 */
        char *body;
} WkStr;
```

这一改动，必定导致 WkStr 对象的构造函数 `wk_str` 需要有所修改，但改动很小，这个重任就交给你了。我先为你探路，看 `wk_str_prefix` 该当如何修改。

既然 WkStr 对象的 `m` 字段记录了存储字符串的内存区域的长度，那么每次在吞入新的 C 字符串时，便可以先判断 WkStr 对象的现有内存是否够用，若够用，则避免一次内存分配，从而为程序的内存性能作出了一次卓越贡献……这个判断很简单，如下

```c
void wk_str_prefix(WkStr *str, const char *raw) {
        ... ... 前奏代码，略 ... ...
        size_t n = strlen(raw);
        size_t m = str->m;
        char *new_body;
        if (m > str->n + n) {
               new_body = str->body
        } else { /* 扩容时，增加 2n 字节 */
                m += (n << 1);
                new_body = realloc(str->body, m);
                if (!new_body) {
                        fprintf(stderr, "wk_str_prefix error: "
                                        "memory not eough!\n");
                        return;
                }
        }
        ... ... 剩余代码，略 ... ...
}
```

好了，现在最关键的技术已经讲完了，至于如何 WkStr 模块的既有代码，这个任务就交给你了！不过，你需要注意，上述代码里的 `n << 1`，用了移位操作符，等效于 `n *= 2` 或 `n = 2 * n`。

`wk_str_prefix` 和 `wk_str_prefix` 的扩容部分是同一套代码，为了方便代码维护，不妨将这个部分抽离出来，作为一个单独的函数，令其作为模块内部的私有函数，不对外公开。该函数可定义为

```c
/* 扩大 str->body 所指空间，使之足以容纳 n 个字节 */
static char *enlarge_body(WkStr *str, size_t n) {
        char *new_body;
        size_t m = str->m;
        if (m > str->n + n) {
                new_body = str->body;
        } else { /* 扩容时，增加 2n 字节 */
                m += (n << 1);
                new_body = realloc(str->body, m);
                if (!new_body) return NULL;
                /* 更新字符串空间长度 */
                str->m = m;
        }
        return new_body;
}
```

## 错误处理机制

在用 C 编程的生涯里，会有很多人告诉你，不要用 goto……

我想告诉你，你最好不要听信任何含有绝对意味的建议。实际上，在 C 语言里，`goto` 语法是很有用的，有两个场景可以大胆用它，其一是从多重循环里一步跳出来，其二是函数内可以用 `goto` 建立简洁的错误处理机制。在此，我们关心一下后者。毕竟，程序的错误，是程序的人生大事，不可轻视。

前文里要求你去实现的 `wk_str_suffix`，在此我给出一个答案：

```c
void wk_str_suffix(WkStr *str, const char *raw) {
        if (!str) {
                fprintf(stderr, "wk_str_suffix error: "
                                "invalid WkStr object!\n");
                return;
        }
        if (!raw || *raw == '\0') return;
        size_t n = strlen(raw);
        char *new_body = realloc(str->body, str->n + n + 1);
        if (!new_body) {
                fprintf(stderr, "wk_str_suffix error: "
                                "memory not eough!\n");
                return;
        }
        /* 将 raw 复制到 new_body 尾部 */
        memcpy(new_body + str->n, raw, n);
        /* 更新字符串及其长度 */
        str->body = new_body;
        str->n += n;
        /* 不要忘记，new_body 所指空间需要以 `\0` 结尾 */
        str->body[str->n] = '\0';
}
```

不要从逻辑的角度去看上述代码，而是从图像的角度去看，其中最显眼之处是什么？是

```c
if (!str) {
        fprintf(stderr, "wk_str_suffix error: "
                        "invalid WkStr object!\n");
        return;
}
```

和

```c
if (!new_body) {
        fprintf(stderr, "wk_str_suffix error: "
                        "memory not eough!\n");
        return;
}
```

现在，看我给你表演一个小魔法：

```c
void wk_str_suffix(WkStr *str, const char *raw) {
        const char *err = NULL;
        if (!str) {
                err = "invalid WkStr object!"; goto ERROR;
        }
        if (!raw || *raw == '\0') return;
        size_t n = strlen(raw);
        char *new_body = realloc(str->body, str->n + n + 1);
        if (!new_body) {
                err = "memory not eough!"; goto ERROR;
        }
        /* 将 raw 复制到 new_body 尾部 */
        memcpy(new_body + str->n, raw, n);
        /* 更新字符串及其长度 */
        str->body = new_body;
        str->n += n;
        /* 不要忘记，new_body 所指空间需要以 `\0` 结尾 */
        str->body[str->n] = '\0';
        return;
ERROR:
        fprintf(stderr, "%s: %s\n", __func__, err);
}
```

> `__func__` 是 C 语言的一个标识符，它以字符串的形式给出当前函数的名字。

这个小魔法，让 `wk_str_suffix` 之前的定义里最显眼的两处区域近乎消失了，而且更重要的是，它成功地将错误集中了起来，而且作为位于函数最为底部的结果……象征着，这是函数最坏的结果。

## 后果自负

`WkStr` 结构体的定义，直接将对象的一切都暴露了出来。一定会有人告诉你，这样非常不安全，因为任何人都可以修改该结构体的所有字段。要让 `WkStr` 变得安全，并非难事，例如

```c
/* wk-str.h */
typedef struct wk_str WkStr;

/* wk-str.c */
struct wk_str {
        size_t n;
        size_t m;
        char *body;
}
```

这样，他人在使用 `WkStr` 对象时，就无法通过它直接访问各个字段了。倘若他们想获得字符串长度，我需要给他们提供 `wk_str_len` 函数，让这个函数返回 `WkStr` 对象的 `n` 字段的值。

可是，我并不想这样做。因为，我相信我自己永远不会去破坏一个 `WkStr` 对象，那么我有什么理由不相信别人不会如此呢？

之所以不能直接修改结构体的字段，是因为结构体是一个整体，只有操作它的函数知道其生命的形式，单独修改某个字段，很容易令其死亡。若有人擅自替你更换了内脏里某个器官，你大概率会因排异反应而死亡。倘若有人愿意与我合作，我会事先告诉他这些。倘若合作期间，他依然在某些代码里直接修改 `WkStr` 对象的字段，我会毫不犹豫，中止与他的合作。

林肯说过，如果你想测试一个人的品性，就给他权力试试。如果我能用 `WkStr` 试探出我的合作者，或者 `WkStr` 的用户的品性，那么 `WkStr` 结构体的成就远远超越了它在代码里的成就。

## 插入与删除

为了实现 `WkObj` 对象的生长，真的有必要实现 `wk_str_prefix` 和 `wk_str_prefix` 这两个函数吗？或者这两个函数真的无法统一吗？实际上 `WkObj` 对象最为一般的生长方式是，应该可在其任意位置吞入 C 字符串，而不是仅限于在首部和尾部吞入。

假设 `wk_str_ins` 函数，其形式为

```c
/* wk-str.h ++ */
void wk_str_ins(WkStr *str, size_t i, const char *raw);
```

若该函数可在 `WkObj` 对象的 `body` 字段所指空间下标为 `i` 的位置插入 C 字符串 ，则 `wk_str_prefix` 和 `wk_str_prefix` 可以定义为

```c
void wk_str_prefix(WkStr *str, const char *raw) {
        wk_str_ins(str, 0, raw);
}

void wk_str_suffix(WkStr *str, const char *raw) {
        wk_str_ins(str, str->n, raw);
}
```

**习题**：实现 `wk_str_ins` 函数，并重新定义 `wk_str_prefix` 与 `wk_str_suffix`。 若你成功实现了 `wk_str_insert`，则从 `WkStr` 对象的 `body` 字段所指区域删除一段子域，然后根据情况适当缩小字符串空间长度，想必也不会多么困难。现在，我给出 `wk_str_del` 的形式，你负责实现吧。

```c
/* 从 str->body 中删除区域 [begin, begin + n)，
   并适当缩容，使得 str->m 不大于 str->n + 2n */
void wk_str_del(WkStr *str, size_t begin, size_t n); 
```

当你完成上述习题后，你应该会发现，此时你已具备玩弄内存于股掌的能力了。

## 完善头文件

你应该能注意到，wk-str.h 里包含了 C 标准库里的三个头文件：

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
```

实际上，在写 C 程序时，有头文件最小包含原则，即每个头文件，应该只包含自身所需要的头文件，且 .c 文件也应当如此。故而，wk-str.h 实际上只需要包含 stdio.h 文件，其他两个头文件需要在 wk-str.c 里包含，亦即

```c
/* wk-str.h */
#include <stdio.h> /* 提供了 size_t 类型 */

/* wk-str.c */
#include <stdlib.h> /* 提供 malloc 和 realloc */
#include <string.h> /* 提供 memcpy */
#include "wk-str.h"
```

之所以要遵循头文件最小包含原则，是因为 `#include` 是预处理指令，编译器会基于该指令将相应的头文件内容与当前头文件的内容合并，然后予以编译，故而 `#include` 一些不必要的头文件会降低程序的编译速度。不过，这通常也不是太大问题。

不过，wk-str.h 里还存在一个很严重的问题，就是当它被某个 .c 文件重复 `#include` 时，例如

```c
/* wk-str-test.c */
#include "wk-str.h"
#include "wk-str.h"
```

gcc 在编译该 .c 文件时，便会报出大量错误。也许你会觉得，我疯了吗？我为何要重复包含同一个头文件呢？实际上头文件的重复包含的情况，在略有一些规模的项目里很容易出现。

例如， wk-str.h 需要 stdio.h，某个其他模块的头文件 wk-foo.h 也需要 stdio.h，当你在 test .c 文件里要调用这两个模块的功能时，会 `#include` 这两个模块的头文件 wk-str.h 和 wk-foo.h，结果便会造成在 test.c 里间接 `#include` 了两次 stdio.h，可是即便遇到这种情况，编译器并不会报错，为何 wk-str.h 被重复 `#include` 就会报错呢？原因在于 wk-str.h 没有采用头文件防重复包含保护。

头文件防重复包含机制，是基于三条预处理指令实现的，例如 wk-str.h 可写为

```c
#ifndef WK_STR_H 
#define WK_STR_H
#include <stdio.h>

typedef struct {
        size_t n;
        size_t m;
        char *body;
} WkStr;
WkStr *wk_str(const char *raw);
void wk_str_free(WkStr *str);

#endif
```

在编译器看来，上述代码的逻辑是，`#ifndef WK_STR_H` 与 `#endif` 之间的代码，只有在 `WK_STR_H` 未定义（not defined） 时才会被编译。基于该逻辑，只需在这段代码里定义 `WK_STR_H` ，便可让编译器再下一次遇到这段代码时便会主动忽略。请记住该机制，并且你所写的每个头文件里都应该使用它。

## 总结

这篇文章已经太长了，然而能读至此处的人，已入 C 门。也许你从未意识到，实际上我们所实现的 WkStr 模块，在一向被视为高深莫测的函数式编程语境里，它有一个很学术的名字——函子。

所谓函子，就是一种数据类型再加上一个特殊的函数，后者可将一些本与该数据类型无关的函数转化为与该数据类型相关的函数，从而使之能够作用于该数据类型的所有对象。例如，`malloc`、`realloc`、`memcpy` 等 C 标准库函数，它们并非为 `WkStr` 类型而设计，然而在 WkStr 模块里，它们在为 `WkStr` 对象而服务。

当然，C 语言并非函数式编程语言，故而函子里的那个特殊的函数，在 WkStr 模块里是隐性的，它实际上就是 WkStr 模块里围绕 `WkStr` 类型而设计的所有函数的总和。 我用以下图示，为你勾画 WkStr 模块的函子图像：

```text
                WkStr「函子」
const char * --------------->  WkStr 结构体类型
malloc 函数   --------------->  wk_str 函数
free   函数  ---------------->  wk_str_free 函数
realloc 函数 ---------------->  wk_str_prefix 函数
... ... 函数 ---------------->  wk_...... 函数
```